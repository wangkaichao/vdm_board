
#rmmod stmmac
#insmod /mnt/mtd/stmmac.ko hitoe=0
#insmod /mnt/mtd/stmmac.ko hitoe=1 tnk_threshold=10240

cd /mnt/mtd
#insmod libahci.ko
#insmod ahci_platform.ko

chmod +x upload.sh

#mount -t tmpfs -o size=15m tmpfs /ramdisk

tar -xjf /mnt/mtd/ko_hi3535.tar.bz2 -C /ramdisk/

cd /ramdisk/ko_hi3535

./load3535 -i

cd /mnt/mtd

rm -fr /ramdisk/ko_hi3535

rm -f /ramdisk/update;

#tar -xjf /mnt/mtd/yuvfile.tar.bz2 -C /ramdisk/

#chmod 777 /mnt/mtd/dhclient-script
#chmod 777 /mnt/mtd/dhclient
#cp -pf /mnt/mtd/dhclient-script /etc/.
#cp -pf /mnt/mtd/dhclient.conf /etc/.

#modprobe sg
#modprobe cdrom
#modprobe isofs
#modprobe sr_mod

#chmod 777 /mnt/mtd/mkisofs
#chmod 777 /mnt/mtd/growisofs
#chmod 777 /mnt/mtd/cdrecord

#mkdir /web
#mkdir /web/html
#chmod 777 /mnt/mtd/mini_httpd

insmod /mnt/mtd/ext.ko

ifconfig eth0 192.168.2.239 netmask 255.255.255.0

mount -t tmpfs -o size=10m tmpfs /tmp
 
#ln -s /mnt/mtd/mkisofs /bin/mkisofs
#ln -s /mnt/mtd/cdrecord /bin/cdrecord
#ln -s /mnt/mtd/HtmlAnvView.cab /web/html/HtmlAnvView.cab
#ln -s /mnt/mtd/index.html /web/html

#LD_LIBRARY_PATH=/usr/local/lib:/usr/local/ssl/lib:/mnt/mtd:/ramdisk
#export LD_LIBRARY_PATH

LD_LIBRARY_PATH=/usr/local/lib:/usr/local/ssl/lib:/mnt/mtd:/ramdisk
export LD_LIBRARY_PATH


telnetd 

echo "6000" > /proc/sys/vm/min_free_kbytes
echo "2024000" > /proc/sys/net/core/rmem_max

#cp /mnt/mtd/testRTSPClient.gz /mnt/mtd/onvifdevice.gz /tmp -f
#cd /tmp
#gunzip *
#chmod 777 *
#/tmp/testRTSPClient &
#/tmp/onvifdevice &


cd /mnt/mtd

#chmod 777 devcheck.sh
#./devcheck.sh

#./systemcall &
#./am6004 &

tar -xzvf bin.tar.gz -C /ramdisk

cd /ramdisk
chmod +x av_server
chmod +x if.sh
chmod +x boardcast_server
chmod +x onvifserver.out
chmod +x test

insmod gpio.ko

./test

./if.sh

#chmod 777 /ramdisk/av_server
#cd /mnt/mtd

./av_server &
./boardcast_server &
