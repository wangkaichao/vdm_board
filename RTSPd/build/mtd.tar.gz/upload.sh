#!/bin/sh

if [ $# != 1 ]
then
	echo "arg error." >> upload.log
	exit 1
else
	if [ ! -e $1 ]
	then
		echo "error.0" >> upload.log
		exit 1
	fi

#	killall sh /mnt/mtd/test.sh &
	mv /sbin/reboot /tmp/reboot
	
	packname=`echo $1 | grep ".tar.gz"`
	if [ $packname != "" ]; then
		echo "update system.."	
		rm /mnt/mtd/bin.tar.gz
		mv $1 /mnt/mtd/bin.tar.gz
	else
		echo "upload application.."
	fi	 

#	echo "continue.0" >> upload.log 
	
	if [ -e /mnt/nfs/callback.sh ]
	then
		/bin/sh /mnt/nfs/callback.sh
		rm /mnt/nfs/callback.sh		
	fi

	mv /tmp/reboot /sbin/reboot	

	/sbin/reboot
fi

	
	
