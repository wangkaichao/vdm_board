
/*  */
static  void get_zimo(char *str, char *buffer)
{
//    printf("str=%s,buffer=%p\n",str,buffer);
    int len;
    int i = 0;
    char *p;
    signed char c1, *str_;
    p = buffer;
    len = strlen(str);
    str_ = (signed char *)str;
    while (i < len)
    {
        c1 = str_[i];
        if(c1 >= 0)//ACSII��
        {
            if(c1<0x20)
            {
                memset(p,0x00,16);
            }
            else
            {
                memcpy(p, &ASC_MSK[(c1-0x1f)*16], 16);
            }

            p = p + 16;
        }
        else //����GB2312��
        {
            getHzKCode(&str_[i], p);
            //p = p + 32;
            p = p + 128;
            i++;
        }
        i++;
    }
}


static  void getHzKCode(signed char *c, char buff[])
{
    unsigned char qh, wh;
    unsigned long offset;
    FILE *HZK;

    if((HZK = fopen("./HZK32", "rb")) == NULL)
    {
        printf("Can't open ./HZK32,Please add it?");
    }
    qh     = *(c) - 0xa0;
    wh     = *(c + 1) - 0xa0;
    offset = (94 * (qh - 1) + (wh - 1)) * 128L;
    fseek(HZK, offset, SEEK_SET);
    fread(buff, 128, 1, HZK);
    fclose(HZK);
}

static inline void lprint(char *origin, char *new_string, char *old_string, unsigned int BitbmpPix_X, int x, int y, char *buffer)
{
    signed char *c = (signed  char *) new_string;
    int i;
    int x_, y_;
    int str_equ = 1;
    x_ = x;
    y_ = y;
    char *bitmap;
    int needCmp = 1;

    if (old_string == NULL)
        needCmp = 0;
    
    /* ��GB2312���루news_tring�� ת��Ϊ����buffer��  */
    get_zimo(new_string, buffer);
		
    bitmap = buffer;
    
    for(i = 0; i < strlen(new_string); i++)
    {
    		/* ASCII */
        if(c[i] >= 0)
        {
            if(needCmp == 1)
            {
                str_equ = memcmp(&new_string[i], &old_string[i], 1);
                if(str_equ != 0)
                {
                    do_blit(bitmap, origin, BitbmpPix_X, x_, y_, asc_font);
                }
            }
            else
            {
                do_blit(bitmap, origin, BitbmpPix_X, x_, y_, asc_font);
            }
            bitmap += 16 * 1; // ��ģ�ڴ�: ascii = 16*1 bytes or 16*8 pixs
            x_ += 8 * 2; // λͼ�ڴ� ARGB1555: ascii = pixs*bytes = 8*2 
        }
        else /* ����GB2312�� */
        {
            if(needCmp)
            {
                str_equ = memcmp(&new_string[i], &old_string[i], 2);
                if(str_equ != 0)
                {
                    do_blit(bitmap, origin, BitbmpPix_X, x_, y_, hz_font);
                }
            }
            else
            {
                do_blit(bitmap, origin, BitbmpPix_X, x_, y_, hz_font);
            }
            bitmap += 32 * 4; // ��ģ�ڴ�: hz_font = 16*2 bytes or 16*16 pixs
            x_ += 64 * 2; // λͼ�ڴ� ARGB1555: hz_font = pixs*bytes = 16*2 
            i++;
        }
    }
    //printf("lprint\n");
}


/**
  * @brief	��λͼ�����һ�����ӻ�ASCII
  * @param	bitmap: ��ǰҪ�����ģ�ĵ�ַ:����16x2 bytes, ASCII:16*1 bytes.
  * @param	origin: λͼ�����ڴ��׵�ַ
  * @param	BitbmpPix_X:λͼ�����п���������Ϊ��λ
  * @param	x:��������λͼ�����ڴ棬x������ʼ��������*2(ARGB1555)��ֵ
  * @param	y:��������λͼ�����ڴ棬��ʼ��������y
  * @param	font:��־����
  *   @arg  hz_font:����
  *   @arg  asc_font:ascii��
  * @retval	
  */
static inline void do_blit(char *bitmap, char *origin, unsigned int BitbmpPix_X, int x, int y, int font)
{
    char *pixel;
    int row, col;
    int y_next = y;
    int j;
    int zom_y;
    
    if(font == hz_font)
    {
        // ������ģ��32��
        for(row = 0; row < 32; row++)
        {
            for (zom_y = 0; zom_y < 2; zom_y++) 
            {
                pixel = origin + (BitbmpPix_X * 2 * (y_next)) + x;  //���������ϲ�ĺ���x��ƫ��:hz=16*2, ascii=8*2
                // ������ģһ��2���ֽ�
                for(j = 0; j < 4; j++)
                {
                    // 1byte = 8bits
                    for(col = 0; col < 8; col++)
                    {
                        if(bitmap[row*4+j] &(0x80 >> col))
                        {
                            pixel[(j*8 + col)*4] = 0x00;
                            pixel[(j*8 + col)*4 + 1] = 0xFC;
                            
                            pixel[(j*8 + col)*4 + 2] = 0x00;
                            pixel[(j*8 + col)*4 + 3] = 0xFC;
                        }
                        else
                        {
                            pixel[(col+j*8)*4] = 0x00;
                            pixel[(col+j*8)*4 + 1] = 0x00;
                            pixel[(col+j*8)*4 + 2] = 0x00;
                            pixel[(col+j*8)*4 + 3] = 0x00;
                        }
                    }
                }
                y_next++; /* Next line in bitmap */
            }
        }
    }
    else
    {
        for(row = 0; row < asc_heigth; row++)
        {
            pixel = origin + (BitbmpPix_X * 2 * (y_next)) + x;
            for(col = 0; col < asc_width; col++)
            {
                if(bitmap[row] &(0x80 >> col))
                {
                    pixel[col*2] = 0x00;
                    pixel[col*2+1] = 0xFC;
                }
                else
                {
                    pixel[col*2] = 0x00;
                    pixel[col*2+1] = 0x00;
                }
            }
            y_next++; /* Next line in bitmap */
        }
    }
}